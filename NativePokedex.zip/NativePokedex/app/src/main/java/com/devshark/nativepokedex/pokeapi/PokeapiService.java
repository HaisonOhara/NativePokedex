package com.devshark.nativepokedex.pokeapi;

import com.devshark.nativepokedex.models.PokemonResposta;

import retrofit2.Call;
import retrofit2.http.GET;

public interface PokeapiService {

    @GET("pokemon")
    Call<PokemonResposta> obterListaPokemon();

}
